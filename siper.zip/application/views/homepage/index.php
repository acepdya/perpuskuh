<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Sistem Perpustakaan Universitas Mana Aja</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicons -->
    <link href="<?= base_url('assets/home/'); ?>img/favicon.png" rel="icon">
    <link href="<?= base_url('assets/home/'); ?>img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="<?= base_url('assets/home/'); ?>lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="<?= base_url('assets/home/'); ?>lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/home/'); ?>lib/animate/animate.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/home/'); ?>lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/home/'); ?>lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/home/'); ?>lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="<?= base_url('assets/home/'); ?>css/style.css" rel="stylesheet">

    <!-- =======================================================
    Theme Name: NewBiz
    Theme URL: https://bootstrapmade.com/newbiz-bootstrap-business-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body>

    <!--==========================
  Header
  ============================-->
    <header id="header" class="fixed-top">
        <div class="container">

            <div class="logo float-left">
                <!-- Uncomment below if you prefer to use an image logo -->
                <!-- <h1 class="text-light"><a href="#header"><span>NewBiz</span></a></h1> -->
                <a href="#intro" class="scrollto">
                    <h1>SIPUMA</h1>
                </a>
            </div>

            <nav class="main-nav float-right d-none d-lg-block">
                <ul>
                    <li class="active"><a href="#intro">Home</a></li>
                    <li><a href="#about">About Us</a></li>
                    <li><a href="#testimonials">Testimonials</a></li>
                    <li><a href="#team">Team</a></li>
                </ul>
            </nav><!-- .main-nav -->

        </div>
    </header><!-- #header -->

    <!--==========================
    Intro Section
  ============================-->
    <section id="intro" class="clearfix">
        <div class="container">

            <div class="intro-img">
                <img src="<?= base_url('assets/home/'); ?>img/aaq.png" alt="" class="img-fluid">
            </div>

            <div class="intro-info">
                <h2>Sistem Perpustakaan Universitas Mana Aja</h2>
                <p>Sistem Perpustakaan Universitas Mana Aja (SIPUMA) merupakan sistem yang dibuat dan dikembangkan untuk
                    memudahkan dalam pelayanan serta memudahkan petugas perpustakaan dalam mengelola perpustakaan. Petugas
                    perpustakaan dapat selalu memonitor tentang ketersediaan buku, daftar buku baru, peminjaman buku dan
                    pengembalian buku.</p>
                <div>
                    <a href="<?= base_url('auth/registration'); ?>" class="btn-get-started scrollto">Daftar</a>
                    <a href="<?= base_url('auth'); ?>" class="btn-services scrollto">Masuk</a>
                </div>
            </div>

        </div>
    </section><!-- #intro -->

    <main id="main">

        <!--==========================
      About Us Section
    ============================-->
        <section id="about">
            <div class="container">

                <header class="section-header">
                    <h3>About SIPUMA</h3>
                    <p>Sistem Perpustakaan Universitas Mana Aja (SIPUMA) merupakan sistem yang dibuat dan dikembangkan untuk
                        memudahkan dalam pelayanan serta memudahkan petugas perpustakaan dalam mengelola perpustakaan. Petugas
                        perpustakaan dapat selalu memonitor tentang ketersediaan buku, daftar buku baru, peminjaman buku dan
                        pengembalian buku.</p>
                </header>

                <div class="row about-container">

                    <div class="row about-extra">
                        <div class="col-lg-6 wow fadeInUp order-1 order-lg-2">
                            <img src="<?= base_url('assets/home/'); ?>img/about-extra-2.svg" class="img-fluid" alt="">
                        </div>

                        <div class="col-lg-6 wow fadeInUp pt-4 pt-lg-0 order-2 order-lg-1">
                            <h4>Sistem Perpustakaan Universitas Mana Aja</h4>
                            <p>
                                Dengan sistem ini, peminjam buku maupun yang mengembalikan buku tidak perlu menunggu lama untuk proses
                                peminjaman/pengembalian buku. Petugas perpustakaan pun tidak akan mengalami kesulitan dalam proses
                                pelaporan kepada kepala perpustakaan. Sistem informasi perpustakaan yang berbasis webbase, memudahkan
                                kita untuk mengakses perpustakaan online, bahkan mengetahui rekam jejak aktifitas pengunjung
                                perpustakaan.
                            </p>
                            <p>
                                Sistem informasi ini juga mempermudah bagi pengguna untuk mencari buku lebih bebas, cepat , leluasa dan
                                nyaman.
                            </p>
                        </div>

                    </div>

                </div>
        </section><!-- #about -->

        <!--==========================
      Clients Section
    ============================-->
        <section id="testimonials" class="section-bg">
            <div class="container">

                <header class="section-header">
                    <h3>Testimonials Pengunjung Perpustakaan</h3>
                </header>

                <div class="row justify-content-center">
                    <div class="col-lg-8">

                        <div class="owl-carousel testimonials-carousel wow fadeInUp">

                            <div class="testimonial-item">
                                <img src="<?= base_url('assets/home/'); ?>img/testimonial-1.jpg" class="testimonial-img" alt="">
                                <h3>Saul Goodman</h3>
                                <h4>Prodi Sistem Komputer</h4>
                                <p>
                                    Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium
                                    quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
                                </p>
                            </div>

                            <div class="testimonial-item">
                                <img src="<?= base_url('assets/home/'); ?>img/testimonial-2.jpg" class="testimonial-img" alt="">
                                <h3>Sara Wilsson</h3>
                                <h4>Prodi Teknik Informatika</h4>
                                <p>
                                    Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis
                                    quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
                                </p>
                            </div>

                            <div class="testimonial-item">
                                <img src="<?= base_url('assets/home/'); ?>img/testimonial-3.jpg" class="testimonial-img" alt="">
                                <h3>Jena Karlis</h3>
                                <h4>Prodi Sistem Informasi</h4>
                                <p>
                                    Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim
                                    tempor labore quem eram duis noster aute amet eram fore quis sint minim.
                                </p>
                            </div>

                            <div class="testimonial-item">
                                <img src="<?= base_url('assets/home/'); ?>img/testimonial-4.jpg" class="testimonial-img" alt="">
                                <h3>Matt Brandon</h3>
                                <h4>Prodi Manajemen</h4>
                                <p>
                                    Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit
                                    minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam.
                                </p>
                            </div>

                            <div class="testimonial-item">
                                <img src="<?= base_url('assets/home/'); ?>img/testimonial-5.jpg" class="testimonial-img" alt="">
                                <h3>John Larson</h3>
                                <h4>Prodi Ilmu Komunikasi</h4>
                                <p>
                                    Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa
                                    labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum quid.
                                </p>
                            </div>

                        </div>

                    </div>
                </div>


            </div>
        </section><!-- #testimonials -->

        <!--==========================
      Team Section
    ============================-->
        <section id="team">
            <div class="container">
                <div class="section-header">
                    <h3>Team Pustakawan SIPUMA</h3>
                    <p>Berikut adalah orang tekece dan terbadai yang berada dalam lingkup UPT Perpustakaan Universitas Mana Aja
                    </p>
                </div>

                <div class="row">

                    <div class="col-lg-3 col-md-6 wow fadeInUp">
                        <div class="member">
                            <img src="<?= base_url('assets/home/'); ?>img/team-1.jpg" class="img-fluid" alt="">
                            <div class="member-info">
                                <div class="member-info-content">
                                    <h4>Walter White</h4>
                                    <span>Kepala UPT Perpustaaan Universitas Mana Aja</span>
                                    <div class="social">
                                        <a href=""><i class="fa fa-twitter"></i></a>
                                        <a href=""><i class="fa fa-facebook"></i></a>
                                        <a href=""><i class="fa fa-google-plus"></i></a>
                                        <a href=""><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="member">
                            <img src="<?= base_url('assets/home/'); ?>img/team-2.jpg" class="img-fluid" alt="">
                            <div class="member-info">
                                <div class="member-info-content">
                                    <h4>Sarah Jhonson</h4>
                                    <span>Wakil UPT Perpustaaan Universitas Mana Aja</span>
                                    <div class="social">
                                        <a href=""><i class="fa fa-twitter"></i></a>
                                        <a href=""><i class="fa fa-facebook"></i></a>
                                        <a href=""><i class="fa fa-google-plus"></i></a>
                                        <a href=""><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.2s">
                        <div class="member">
                            <img src="<?= base_url('assets/home/'); ?>img/team-3.jpg" class="img-fluid" alt="">
                            <div class="member-info">
                                <div class="member-info-content">
                                    <h4>William Anderson</h4>
                                    <span>Pustakawan 1 UPT Perpustaaan Universitas Mana Aja</span>
                                    <div class="social">
                                        <a href=""><i class="fa fa-twitter"></i></a>
                                        <a href=""><i class="fa fa-facebook"></i></a>
                                        <a href=""><i class="fa fa-google-plus"></i></a>
                                        <a href=""><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="member">
                            <img src="<?= base_url('assets/home/'); ?>img/team-4.jpg" class="img-fluid" alt="">
                            <div class="member-info">
                                <div class="member-info-content">
                                    <h4>Amanda Jepson</h4>
                                    <span>Pustakawan 2 UPT Perpustaaan Universitas Mana Aja</span>
                                    <div class="social">
                                        <a href=""><i class="fa fa-twitter"></i></a>
                                        <a href=""><i class="fa fa-facebook"></i></a>
                                        <a href=""><i class="fa fa-google-plus"></i></a>
                                        <a href=""><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </section><!-- #team -->

    </main>

    <!--==========================
    Footer
  ============================-->
    <footer id="footer">
        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-4 col-md-6 footer-info">
                        <h3>SIPUMA</h3>
                        <p>Sistem Perpustakaan Universitas Mana Aja (SIPUMA) merupakan sistem yang dibuat dan dikembangkan untuk
                            memudahkan dalam pelayanan serta memudahkan petugas perpustakaan dalam mengelola perpustakaan. Petugas
                            perpustakaan dapat selalu memonitor tentang ketersediaan buku, daftar buku baru, peminjaman buku dan
                            pengembalian buku.</p>
                    </div>

                    <div class="col-lg-2 col-md-6 footer-links">
                        <h4>Useful Links</h4>
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#">About us</a></li>
                            <li><a href="#">Services</a></li>
                            <li><a href="#">Terms of service</a></li>
                            <li><a href="#">Privacy policy</a></li>
                        </ul>
                    </div>

                    <div class="col-lg-3 col-md-6 footer-contact">
                        <h4>Contact Us</h4>
                        <p>
                            A108 Adam Street <br>
                            New York, NY 535022<br>
                            United States <br>
                            <strong>Phone:</strong> +1 5589 55488 55<br>
                            <strong>Email:</strong> info@example.com<br>
                        </p>

                        <div class="social-links">
                            <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                            <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                            <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
                            <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
                            <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
                        </div>

                    </div>

                    <div class="col-lg-3 col-md-6 footer-newsletter">
                        <h4>Our Newsletter</h4>
                        <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna veniam enim veniam illum dolore
                            legam minim quorum culpa amet magna export quem marada parida nodela caramase seza.</p>
                        <form action="" method="post">
                            <input type="email" name="email"><input type="submit" value="Subscribe">
                        </form>
                    </div>

                </div>
            </div>
        </div>

        <div class="container">
            <div class="copyright">
                &copy; Copyright <strong>SIPUMA</strong>. All Rights Reserved
            </div>
            <div class="credits">
                <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=NewBiz
        -->
                Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
            </div>
        </div>
    </footer><!-- #footer -->

    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
    <!-- Uncomment below i you want to use a preloader -->
    <!-- <div id="preloader"></div> -->

    <!-- JavaScript Libraries -->
    <script src="<?= base_url('assets/home/'); ?>lib/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets/home/'); ?>lib/jquery/jquery-migrate.min.js"></script>
    <script src="<?= base_url('assets/home/'); ?>lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url('assets/home/'); ?>lib/easing/easing.min.js"></script>
    <script src="<?= base_url('assets/home/'); ?>lib/mobile-nav/mobile-nav.js"></script>
    <script src="<?= base_url('assets/home/'); ?>lib/wow/wow.min.js"></script>
    <script src="<?= base_url('assets/home/'); ?>lib/waypoints/waypoints.min.js"></script>
    <script src="<?= base_url('assets/home/'); ?>lib/counterup/counterup.min.js"></script>
    <script src="<?= base_url('assets/home/'); ?>lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?= base_url('assets/home/'); ?>lib/isotope/isotope.pkgd.min.js"></script>
    <script src="<?= base_url('assets/home/'); ?>lib/lightbox/js/lightbox.min.js"></script>
    <!-- Contact Form JavaScript File -->
    <script src="<?= base_url('assets/home/'); ?>contactform/contactform.js"></script>

    <!-- Template Main Javascript File -->
    <script src="<?= base_url('assets/home/'); ?>js/main.js"></script>

</body>

</html>